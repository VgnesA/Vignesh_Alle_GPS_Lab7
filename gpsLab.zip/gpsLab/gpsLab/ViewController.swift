//
//  ViewController.swift
//  gpsLab
//
//  Created by user256361 on 7/13/24.
//
import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    var tripStart = false
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.showsUserLocation = true
        topBar.backgroundColor = .gray
        bottomBar.backgroundColor = .white
        locationManager.delegate = self
        mapView.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        // Do any additional setup after loading the view.
        
    }
    
    @IBOutlet weak var startB: UIButton!
    @IBOutlet weak var endB: UIButton!
    @IBOutlet weak var currentSpeed: UILabel!
    @IBOutlet weak var maxSpeed: UILabel!
    @IBOutlet weak var avgSpeed: UILabel!
    @IBOutlet weak var distance: UILabel!
    @IBOutlet weak var maxAcc: UILabel!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var topBar: UIView!
    @IBOutlet weak var bottomBar: UIView!
    
    var startTime : Date?
    
    var speedMax = 0.0
    var dist = 0.0
    var accMax = 0.0
    
    
    @IBAction func StartTrip(_ sender: Any) {
        tripStart = true
          bottomBar.backgroundColor =  .green
          startTime = Date()
          mapView.showsUserLocation = true
          locationManager.startUpdatingLocation()
            maxSpeed.text = "0.0 km/h"
            avgSpeed.text = "0.0 km/h"
            distance.text = "0.0 km/h"
            currentSpeed.text = "0.0 km/h"
            maxAcc.text = "0.0 m/s^2"
    }
    
    @IBAction func EndTrip(_ sender: Any) {
        tripStart = false
          bottomBar.backgroundColor = .gray
          currentSpeed.text = "0.0 km/h"
          topBar.backgroundColor = .red
          maxSpeed.text = "0.0 km/h"
          avgSpeed.text = "0.0 km/h"
          distance.text = "0.0 km/h"
          locationManager.stopUpdatingLocation()
          mapView.showsUserLocation = false
          maxAcc.text = "0.0 m/s^2"
    }
    var lastLocation :CLLocation?
    var myLocation : CLLocation?
    var mySpeed = 0.0
    var previousSpeed = 0.0
    var averageSpeedCount = 0.0
    var sum = 0.0
    var acceleration = 0.0
    var speedsArray : [Double] = []
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         
      myLocation = locations.last!
    if (lastLocation != nil){
      let distanceValue = myLocation!.distance(from: lastLocation!)
      dist += distanceValue
      distance.text = "\(String(round(dist / 1000 * 100)/100.0)) km"
      
      mySpeed = myLocation!.speed * 3.6
      if(tripStart == true){
      if(mySpeed > 115.0){
          topBar.backgroundColor = UIColor.red
      }else{
          topBar.backgroundColor = UIColor.white
      }
          
      }
      sum += mySpeed
      speedsArray.append(mySpeed)
       
      averageSpeedCount = (sum / Double(speedsArray.count))
      avgSpeed.text = "\(String(round(averageSpeedCount * 100)/100.0)) km/h"
      
      let deltaV = mySpeed - previousSpeed
      let currentTime = myLocation!.timestamp.timeIntervalSince(startTime!)
      let previousTime = lastLocation!.timestamp.timeIntervalSince(startTime!)
      let deltaT = currentTime - previousTime
      acceleration = deltaV / deltaT
      if(accMax < acceleration){
          accMax = acceleration
      }
      maxAcc.text = "\(String(round(accMax * 100)/100.0)) m/s^2"
      previousSpeed = mySpeed
          
      maxSpeed.text = String(speedMax)
      currentSpeed.text = "\(String(round(mySpeed * 100)/100.0)) km/h"
      if(speedMax < mySpeed){
          speedMax = mySpeed
      }
      maxSpeed.text = "\(String(round(speedMax * 100)/100.0)) km"

          
      
         //making map center to current location
         mapView.setCenter(myLocation!.coordinate, animated: true)
             
         //zooming map and setting it to 1000 meters from both latitude and longitude
             if tripStart {
                 mapView.setRegion(MKCoordinateRegion(center: myLocation!.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000), animated: true)
             }
    }
    lastLocation = myLocation
    }
    
}
